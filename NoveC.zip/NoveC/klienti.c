#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "klient.h"
#include "klienti.h"
#include "konstanty.h"
#include "hra.h"
#include "globalni_promenne.h"

int funkce (){
    return 0;
}

int klient_zaregiastruj_klienta(int id, char *jmeno, char *heslo){
    //zde nejprv musim uverit jeho unikatnost
   
    if ((GLOBAL_klienti + id)->stav_stavoveho_diagramu !=0){
        return -1; //nemelo by se stat neco je blbe, nekdo se prihlasuje kdyz nema
    }
    (GLOBAL_klienti + id)->jmeno_hrace = jmeno;
    (GLOBAL_klienti +id)->heslo = heslo;
    return 0;
    
}

int klient_znovu_prihlaseni(int fd, char *jmeno, char *heslo){
    int i;
    for (i =0; i<GLOBAL_pocet; i++){
        if ((strcmp(jmeno, (GLOBAL_klienti +i)->jmeno_hrace)== 0) && (strcmp(heslo, (GLOBAL_klienti +i)->heslo)==0) ){
            (GLOBAL_klienti + i)->stav_stavoveho_diagramu=1;
            (GLOBAL_klienti + i)->doba_necinosti = 0;
            (GLOBAL_klienti + i)->fd = fd;
            (GLOBAL_klienti + i)->stav_stavoveho_diagramu = (GLOBAL_klienti + i)->stav_pred_odpojenim;
             return 0; //overeni ok
        }
    }
     return -1; //overeni selhalo
   
}

int klienti_vrat_fd_klienta(char* jmeno_hrace){
    int fd;
    int navrat=klienti_vrat_id_klienta(jmeno_hrace);
    if (navrat == -1) {
        return navrat;
    }
    fd = (GLOBAL_klienti + navrat)->fd;
  //  printf("FD JE %d\n" , fd);
   
    return fd;
    return 5;
}

int klienti_vrat_id_klienta(char* jmeno_hrace){
   int i;
    for(i=0; i<GLOBAL_pocet; i++){
        if (strcmp((GLOBAL_klienti+i)->jmeno_hrace, jmeno_hrace) == 0){
        //    printf("POROVNAVANI %d  nalezen hrac %s\n",  i, jmeno_hrace);
            return i;
        }
    }
   i=-1;
    return i;
    
}

int klienti_vrat_id_klienta_fd(int fd){
   int i;
  // printf("pocet %d \n", GLOBAL_pocet);
    for(i=0; i<GLOBAL_pocet; i++){
        
       // printf("fd je %d \n", (GLOBAL_klienti + i)->fd);
        if ((GLOBAL_klienti+i)->fd == fd){
        //    printf("POROVNAVANI %d \n",  fd);
            return i;
        }
    }
   i=-1;
    return i;
    
}

int klienti_pridej_klienta(int fd){
  //  (klienti+pocet)  = klient_vytvor_klienta(fd, jmeno_hrace);
    //kam, co , kolik
    
     klient s_kl;
     klient *kli = &s_kl;
     memset(kli, 0, sizeof(klient));
     klient_vytvor_klienta(kli, fd);
     
     memcpy((GLOBAL_klienti + GLOBAL_pocet), kli, sizeof(struct klient));
   
    
     GLOBAL_pocet++;
   // printf("pridan hrac na pozici %d", GLOBAL_pocet );
    
    return 0;
   
}

int klienti_vypis_klienty(){
    int i;
    for( i=0; i<GLOBAL_pocet;i++){
     //   printf("klienti %d ma jmeno %s\n", i, (GLOBAL_klienti + i)->jmeno_hrace ) ;
    }
    
}

/**
 * Odhlásí klienta - nastaví mu příznak že je odhlášený
 * @param id
 * @param fd
 * @param client_socks
 * @return 
 */
int klienti_odhlas_klienta(int id,int fd, fd_set *client_socks){
    (GLOBAL_klienti + id)->stav_pred_odpojenim = (GLOBAL_klienti + id)->stav_stavoveho_diagramu;
    (GLOBAL_klienti +id)->stav_stavoveho_diagramu = 5;
    (GLOBAL_klienti +id)->zamek_odpovedi = 0;
    int nalezeni =hry_vrat_id_hry_hrac( (GLOBAL_klienti + id)->jmeno_hrace);
     close(fd);
    FD_CLR(fd, client_socks );
    return 0;
}

/**
 * Odebere klienta z pole klientu. Uplně ho tím pádem zapomene. Sesype klienty.
 * @param id
 * @param fd
 * @param client_socks
 * @return 
 */
int klienti_odeber_klienta(int id, int fd, fd_set *client_socks){
      //  printf("posledni je jmeno %s   heslo %s  \n", (GLOBAL_klienti + GLOBAL_pocet -1)->jmeno_hrace, (GLOBAL_klienti + GLOBAL_pocet - 1)->heslo);
        //printf("Odebiran je klient s id %d  jmene %s \n" , id, (GLOBAL_klienti + id)->jmeno_hrace);
    int i;
/*     if ((GLOBAL_hry + (GLOBAL_klienti + id)->herni_mistnost)->id_hrac_dva == id) {
         (GLOBAL_hry + (GLOBAL_klienti + id)->herni_mistnost)->id_hrac_dva = -1; //taky tu musi bejt nejakej zamek urcite
     } else if ((GLOBAL_hry + (GLOBAL_klienti + id)->herni_mistnost)->id_hrac_jedna == id) {
         (GLOBAL_hry + (GLOBAL_klienti + id)->herni_mistnost)->id_hrac_jedna = -1;
     }*/
    
    char *jm = malloc(20);
    memcpy(jm, (GLOBAL_klienti +id)->jmeno_hrace, 20);
    if (strcmp((GLOBAL_klienti +id)->jmeno_hrace,"") != 0 ){
        //printf("jmeno bude odebrano \n");
          globalni_promenne_odeber_jmeno((GLOBAL_klienti + id)->jmeno_hrace);
    }
   
    /*   printf("-------------------------------------------------\n");
    printf("melo se:  %d \n", klienti_vrat_id_klienta(jm) );
     printf("---------------------------------------------\n"); */
    for(i=id; i <GLOBAL_pocet-1; i++){
        //tady je asi chyba nebot zustane nekde ulozenej starej fd i po odpojeni*/
      //  printf("for cyklus %s \n", (GLOBAL_klienti + i)->jmeno_hrace);
        while(GLOBAL_zamek ==1){
            usleep(9);
        }
        GLOBAL_zamek =1;
        memcpy(GLOBAL_klienti + i, GLOBAL_klienti + i+1, sizeof(struct klient));
        (GLOBAL_klienti + i)->jmeno_hrace = strdup ((GLOBAL_klienti + i + 1)->jmeno_hrace);
        (GLOBAL_klienti + i)->heslo = strdup ((GLOBAL_klienti + i + 1)->heslo);
        GLOBAL_zamek = 0;
    }
    close(fd);
    FD_CLR( fd, client_socks );
 //   printf("pocet %d odstranuju jmeno %s   heslo %s  \n", GLOBAL_pocet, (GLOBAL_klienti + GLOBAL_pocet - 1)->jmeno_hrace, (GLOBAL_klienti + GLOBAL_pocet - 1)->heslo);
   // printf(" predtim je- %s \n ", (GLOBAL_klienti + GLOBAL_pocet -2)->jmeno_hrace);
    free((GLOBAL_klienti + GLOBAL_pocet -1)->jmeno_hrace);
    free((GLOBAL_klienti + GLOBAL_pocet - 1)->heslo);
   
    (GLOBAL_klienti + GLOBAL_pocet -1)->odpoved = 0;
    (GLOBAL_klienti + GLOBAL_pocet -1)->stav_stavoveho_diagramu = 0;
    (GLOBAL_klienti + GLOBAL_pocet -1)->zamek_odpovedi = 0;
    (GLOBAL_klienti + GLOBAL_pocet -1)->pocet_vadnych_zprav = 0;
    (GLOBAL_klienti + GLOBAL_pocet -1)->stav_pred_odpojenim = 0;
    (GLOBAL_klienti + GLOBAL_pocet -1)->fd = -1;
    (GLOBAL_klienti + GLOBAL_pocet -1)->herni_mistnost = -1;
    (GLOBAL_klienti + GLOBAL_pocet -1)->jmeno_hrace = calloc(MAX_DELKA_JMENA, 1);
    memcpy( (GLOBAL_klienti + GLOBAL_pocet -1)->jmeno_hrace, "", 1);
    (GLOBAL_klienti + GLOBAL_pocet -1)->heslo = calloc(MAX_DELKA_JMENA, 1);
   /* printf("----------------------------- %s \n ", (GLOBAL_klienti + GLOBAL_pocet -2)->jmeno_hrace);
    printf("-------------------------------------------------\n");
    printf("nalezne se:  %d \n", klienti_vrat_id_klienta(jm) );
     printf("---------------------------------------------\n"); */ 
    //zde na toho posledniho zavolam free
    GLOBAL_pocet--;
    
    
    klienti_vypis_klienty();
   
    return 0;
}
   
int klienti_odstran_prebytecneho_klienta(int id, int fd){
    int iddva=0;
    int i;
    for(i=0; i<GLOBAL_pocet; i++){
         while(GLOBAL_zamek ==1){
            usleep(9);
        }
        GLOBAL_zamek =1;
    //    printf("fd je %d \n", (GLOBAL_klienti + i)->fd);
        if (((GLOBAL_klienti+i)->fd == fd)&&(i!=id)){
      //      printf("POROVNAVANI %d \n",  i);
            iddva= i;
        }
        GLOBAL_zamek=0;
    }
    
    
    for(i=iddva; i <GLOBAL_pocet-1; i++){
        //tady je asi chyba nebot zustane nekde ulozenej starej fd i po odpojeni*/
         while(GLOBAL_zamek ==1){
            usleep(9);
            //printf("spim klienti zacaek");
        }
        GLOBAL_zamek =1;
        memcpy(GLOBAL_klienti + i, GLOBAL_klienti + i+1, sizeof(struct klient));
        (GLOBAL_klienti + i)->jmeno_hrace = strdup ((GLOBAL_klienti + i + 1)->jmeno_hrace);
        (GLOBAL_klienti + i)->heslo = strdup ((GLOBAL_klienti + i + 1)->heslo);
        GLOBAL_zamek=0;
        
    }
    
    
  //  printf("odstran prebytecneho klienta pocet %d odstranuju jmeno %s   heslo %s  \n", GLOBAL_pocet, (GLOBAL_klienti + GLOBAL_pocet - 1)->jmeno_hrace, (GLOBAL_klienti + GLOBAL_pocet - 1)->heslo);
    free((GLOBAL_klienti + GLOBAL_pocet -1)->jmeno_hrace);
    free((GLOBAL_klienti + GLOBAL_pocet - 1)->heslo);
   
        (GLOBAL_klienti + GLOBAL_pocet -1)->odpoved = 0;
        (GLOBAL_klienti + GLOBAL_pocet -1)->stav_stavoveho_diagramu = 0;
        (GLOBAL_klienti + GLOBAL_pocet -1)->zamek_odpovedi = 0;
        (GLOBAL_klienti + GLOBAL_pocet -1)->pocet_vadnych_zprav = 0;
        (GLOBAL_klienti + GLOBAL_pocet -1)->stav_pred_odpojenim = 0;
        (GLOBAL_klienti + GLOBAL_pocet -1)->fd = -1;
        (GLOBAL_klienti + GLOBAL_pocet -1)->herni_mistnost = -1;
        (GLOBAL_klienti + GLOBAL_pocet -1)->jmeno_hrace = calloc(MAX_DELKA_JMENA, 1);
        memcpy( (GLOBAL_klienti + GLOBAL_pocet -1)->jmeno_hrace, "", 1);
        (GLOBAL_klienti + GLOBAL_pocet -1)->heslo = calloc(MAX_DELKA_JMENA, 1);
    
    
    GLOBAL_pocet--;
    
    return 0;
}