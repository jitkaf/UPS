/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   hry.c
 * Author: jitka
 * 
 * Created on 18. prosince 2016, 18:35
 */
#include "hry.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "konstanty.h"
#include "globalni_promenne.h"
#include "tcp_server.h"
#include "hra.h"
#include "klient.h"
#include <pthread.h>
#include "herni_otazky.h"
#include "klienti.h"

/**
 * Přiřadí hráče do hry, pohlídá si, který má bejt první a který druhý
 * @param id_hrac
 * @return 
 */
int hry_prirad_do_hry(int id_hrac) {
    int i;
 //   printf("Přiřazuji do hry hráče s indexem: %d \n", id_hrac);
    for (i = 0; i < MAX_HER; i++) {
        //v ifech nejaky zamek aby se to provedlo atomicky
         if ((GLOBAL_hry + i)->stav == 1) { ///pridavam druheho hrace
            (GLOBAL_hry + i)->stav = 2;
            memcpy((GLOBAL_hry + i)->jmeno_hrac_dva, (GLOBAL_klienti + id_hrac)->jmeno_hrace, 20);
            //ZDE BUDU JESTE TVORIT VLAKNO PRO HRU A HRA ZACNE
            printf("Do hry byl přidán druhý hrá \n");
            (GLOBAL_klienti + id_hrac)->herni_mistnost = i;
            hry_vytvor_vlakno_hry(i);

            return 0;
        }
    }
    
    
    
    for (i = 0; i < MAX_HER; i++) {
        //v ifech nejaky zamek aby se to provedlo atomicky
        if ((GLOBAL_hry + i)->stav == 0) {
            (GLOBAL_hry + i)->stav = 1;
            memcpy((GLOBAL_hry + i)->jmeno_hrac_jedna, (GLOBAL_klienti + id_hrac)->jmeno_hrace, 20);
            printf("Do hry byl přidán první hráč. \n");
            (GLOBAL_klienti + id_hrac)->herni_mistnost = i;
            return 0;
        } else if ((GLOBAL_hry + i)->stav == 1) { ///pridavam druheho hrace
            (GLOBAL_hry + i)->stav = 2;
            memcpy((GLOBAL_hry + i)->jmeno_hrac_dva, (GLOBAL_klienti + id_hrac)->jmeno_hrace, 20);
            //ZDE BUDU JESTE TVORIT VLAKNO PRO HRU A HRA ZACNE
            printf("Do hry byl přidán druhý hrá \n");
            (GLOBAL_klienti + id_hrac)->herni_mistnost = i;
            hry_vytvor_vlakno_hry(i);

            return 0;
        }
    }


    return -1; //signalizuje ze je plno
}

/**
 * Vytvoří vlákno hry
 * @param id_hry
 * @return 
 */
int hry_vytvor_vlakno_hry(int id_hry) {
    printf("Vytvářím vlákno hry. \n");
    int *arg = malloc(sizeof (*arg));
    *arg = id_hry;

    if ((GLOBAL_hry + id_hry)->prirazene_vlakno != 0) {
        pthread_join((GLOBAL_hry + id_hry)->vlakno, NULL);
    }
    (GLOBAL_hry + id_hry)->prirazene_vlakno = 1;
    pthread_create(&((GLOBAL_hry + id_hry)->vlakno), 0, hry_smycka_vlakna, arg);

    return 0;
}

/**
 * Vytvoří herní smyčku.
 * Pošle vždy otázku připojeným hráčům a nachvíli se uspí, aby dostali prostor pro zaslání odpovědi.
 * Je zde spousta nepěkných složitých podmínek, kterí slouží k ověření, zda jsou hráči připojeni a čekají na otázku, aby nedošlo k záměně
 * klientů kvůli paraelnímu běhu.
 * Tento složitý složeným systém podmínek by šel nahradit zámkem, to by ale zase zkomplikovalo "sesypávání" klientů při odpojení.
 * @param arg
 * @return 
 */
void *hry_smycka_vlakna(void *arg) {
    int id_hry = *((int *) arg);
    int i;  //osetrit kriticke sekce
    int fd_prvni = klienti_vrat_fd_klienta((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
    int id_prvni = klienti_vrat_id_klienta((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
     if (id_prvni != -1){
         (GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu = 3;
    }
     else{
         memcpy((GLOBAL_hry + id_hry)->jmeno_hrac_jedna, "|||||||||||||||||\0", 20);
     }
    
    
    
    int fd_druhej =klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_dva);
    int id_druhej = klienti_vrat_id_klienta( (GLOBAL_hry + id_hry)->jmeno_hrac_dva);
    if(id_druhej != -1){
     (GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu = 3;
    }
    else{
         memcpy((GLOBAL_hry + id_hry)->jmeno_hrac_dva, "|||||||||||||||||\0", 20);
     }
    
    
    
    
    for (i = 0; i < POCET_OTAZEK; i++) {
     //   printf("otazka cislo %d \n", i);
        while(GLOBAL_zamek ==1){
            usleep(10);
           // printf("spím hry \n");
        }
        GLOBAL_zamek = 1;
        id_prvni = klienti_vrat_id_klienta((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);      
        //je grac jedna a hraje
        if ((id_prvni !=-1) && ((((GLOBAL_klienti + id_prvni))->stav_stavoveho_diagramu == 3) || ((GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu == 1))) {
            fd_prvni = klienti_vrat_fd_klienta((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
            tcp_server_send_message(fd_prvni, (otazky + i)->text);
        }
        
        
        id_druhej = klienti_vrat_id_klienta((GLOBAL_hry + id_hry)->jmeno_hrac_dva);
        
        if ((id_druhej != -1) && (((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu == 3) || ((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu == 1))) {
            fd_druhej = klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_dva);
            tcp_server_send_message(fd_druhej, (otazky + i)->text);
        }
        

        GLOBAL_zamek=0;
        usleep(10000000); //doba za kterou musí hráči odpovědět
        while(GLOBAL_zamek == 1){
            usleep(10);
          //  printf("spim hry dva");
        }
        GLOBAL_zamek=1;
        while (((id_prvni != -1)&&((GLOBAL_klienti + id_prvni)->zamek_odpovedi != 0)) || ((id_druhej != -1)&&((GLOBAL_klienti + id_druhej)->zamek_odpovedi != 0))) {
            id_prvni = klienti_vrat_id_klienta((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
            id_druhej = klienti_vrat_id_klienta( (GLOBAL_hry + id_hry)->jmeno_hrac_dva);
          //  printf("zamake jede %d   zamek druhej %d \n", (GLOBAL_klienti + id_prvni)->zamek_odpovedi, (GLOBAL_klienti + id_druhej)->zamek_odpovedi);
            //printf("id prvni  %d    a id druhej   %d \n", id_prvni, id_druhej);
            usleep(10);
        }
        int odpoved_jedna = -1;
        int odpoved_dva = -1;
      //  printf ("skore hrac jedna %d\n", (GLOBAL_hry +id_hry)->score_hrac_jedna);
        //printf("skore hrac dva %d \n", (GLOBAL_hry +id_hry)->score_hrac_dva);
        if (id_prvni != -1) {
            (GLOBAL_klienti + id_prvni)->zamek_odpovedi = 1;
            odpoved_jedna = (GLOBAL_klienti + id_prvni)->odpoved;
        }
        else{
            memcpy((GLOBAL_hry + id_hry)->jmeno_hrac_jedna, "|||||||||||||||||\0", 20);
        }
        if (id_druhej != -1) {
            (GLOBAL_klienti + id_druhej)->zamek_odpovedi = 1;
            odpoved_dva = (GLOBAL_klienti + id_druhej)->odpoved;
        }
        else{
            memcpy((GLOBAL_hry + id_hry)->jmeno_hrac_dva, "|||||||||||||||||\0", 20);
        }
        
        hra_vyhodnot_odpoved(GLOBAL_hry + id_hry, (otazky + i)->odpoved, odpoved_jedna, odpoved_dva);

        if ((id_prvni) != -1) {
            (GLOBAL_klienti + id_prvni)->odpoved = -1;
            (GLOBAL_klienti + id_prvni)->zamek_odpovedi = 0;
        }
        else{
         memcpy((GLOBAL_hry + id_hry)->jmeno_hrac_jedna, "|||||||||||||||||\0", 20);
        }
        if (id_druhej != -1) {
            (GLOBAL_klienti + id_druhej)->odpoved = -1;
            (GLOBAL_klienti + id_druhej)->zamek_odpovedi = 0;
        }
        else{
        memcpy((GLOBAL_hry + id_hry)->jmeno_hrac_dva, "|||||||||||||||||\0", 20);
     }
        
        GLOBAL_zamek=0;

    }

     while(GLOBAL_zamek == 1){
            usleep(10);
         //   printf("spim hry tri");
        }
        GLOBAL_zamek=1;
    while (((GLOBAL_klienti + id_prvni)->zamek_odpovedi != 0) || ((GLOBAL_klienti + id_druhej)->zamek_odpovedi != 0)) {
       // printf("zamek");
        id_prvni = klienti_vrat_id_klienta((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
        id_druhej = klienti_vrat_id_klienta( (GLOBAL_hry + id_hry)->jmeno_hrac_dva);
        usleep(10);
    }
    (GLOBAL_klienti + id_prvni)->zamek_odpovedi = 1;
    (GLOBAL_klienti + id_druhej)->zamek_odpovedi = 1;
    if ((GLOBAL_hry + id_hry)->score_hrac_jedna > (GLOBAL_hry + id_hry)->score_hrac_dva) {
        if ((id_prvni != -1) && (((GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu ==3) || ((GLOBAL_klienti + id_prvni))->stav_stavoveho_diagramu == 1)) {
            fd_prvni =klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
            tcp_server_send_message(fd_prvni, "5|1");
        }
        if ((id_druhej != -1) && ((((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu ==3)) || ((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu == 1))) {
            fd_druhej =klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_dva);
            tcp_server_send_message(fd_druhej, "5|2");
        }
    }
    else if  ((GLOBAL_hry + id_hry)->score_hrac_jedna < (GLOBAL_hry + id_hry)->score_hrac_dva) {
        if ((id_prvni != -1) && ((((GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu == 3)) || ((GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu == 1))) {
            fd_prvni =klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
            tcp_server_send_message(fd_prvni, "5|2");
        }
        if ((id_druhej != -1) && ((((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu == 3)) || ((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu == 1))) {
            fd_druhej =klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_dva);
            tcp_server_send_message(fd_druhej, "5|1");
        }
    } 
    else {
        if ((id_prvni!= -1) && ((((GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu == 3)) || ((GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu == 1))) {
            fd_prvni =klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_jedna);
            tcp_server_send_message(fd_prvni, "5|0");
        }
        if ((id_druhej != -1) && ((((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu == 3)) || ((GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu == 1))) {
            fd_druhej =klienti_vrat_fd_klienta ((GLOBAL_hry + id_hry)->jmeno_hrac_dva);
            tcp_server_send_message(fd_druhej, "5|0");

        }
    }

    
    (GLOBAL_klienti + id_prvni)->zamek_odpovedi = 0;
    (GLOBAL_klienti + id_druhej)->zamek_odpovedi = 0;
    (GLOBAL_klienti + id_prvni)->stav_stavoveho_diagramu = 1;
    (GLOBAL_klienti + id_druhej)->stav_stavoveho_diagramu = 1;
     GLOBAL_zamek = 0;
    
    hra_vyrezetuj_hru((GLOBAL_hry + id_hry));
    /* 
     (GLOBAL_klienti + (GLOBAL_hry+id_hry)->id_hrac_dva)->stav_stavoveho_diagramu=1;
      (GLOBAL_klienti + (GLOBAL_hry+id_hry)->id_hrac_jedna)->stav_stavoveho_diagramu=1;*/
    (GLOBAL_hry + id_hry)->stav = 0;
    
}



int hry_vrat_id_hry_hrac(char * jmeno){
    int i;
    for(i=0; i<MAX_HER; i++){
        if(((GLOBAL_hry +i) != NULL) && ( (strcmp(((GLOBAL_hry)->jmeno_hrac_jedna), jmeno) == 0) || ((strcmp((GLOBAL_hry->jmeno_hrac_dva), jmeno)==0)))){
            return i;
        }
    }
    
    return -1;
    
}
