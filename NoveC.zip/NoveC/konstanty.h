/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Konstanty.h
 * Author: jitka
 *
 * Created on 4. prosince 2016, 10:20
 */

#ifndef KONSTANTY_H
#define KONSTANTY_H

#define MAX_KLIENTU 10
#define MAX_HER 10
#define  MAX_DELKA_JMENA 20
#define DELKA_ODPOVED 1
#define PORT 20004

#define POCET_OTAZEK 10
#define DELKA_OZAZKY 100
#define DELKA_MOZNOSTI 10
/*stavy stavoveho diagramu*/
#define PRAZDNA_HRA 0
#define CEKA_NA_PRIPOJENI_Hrace 1
#define HRAJE_SE 2
#define DOHRANO 3
/*pocet vadnych zprav ktere muze klient poslat nez je odpojen*/
#define TOLERANCE 1
#define PRAZDNE_JMENO 0
#define MAX_DELKA_ZPRAVY_KLIENT 50


#endif /* KONSTANTY_H */
